emotion_label = {'0': "happy",
                 "1": "angry",
                 "2": "bored",
                 "3": "sad",
                 "4": "clam",
                 "5": "worried",
                 "6": "tense",
                 "7": 'surprise',
                 # "8": "emotional"
                 }

emotional_dict = {
    'happy': '开心',
    'angry': '生气',
    'bored': '无聊',
    'sad': '伤心',
    'clam': '沉默寡言',
    'worried': '担忧',
    'tense': '紧张焦虑',
    'surprise': '惊讶'
}
