cifar10_label = {'0': 'plane',
                 '1': 'car',
                 '2': 'bird',
                 '3': 'cat',
                 '4': 'deer',
                 '5': 'dog',
                 '6': 'frog',
                 '7': 'horse',
                 '8': 'ship',
                 '9': 'truck'
                 }

cifar10_dict = {'plane': '灰机',
                'car': '车车',
                'bird': '鸟儿',
                'cat': '喵嗷wu',
                'deer': '🦌',
                'dog': '狗狗',
                'frog': '蛙~',
                'horse': '🐎',
                'ship': '船',
                'truck': '卡车。。。创！'
                }
